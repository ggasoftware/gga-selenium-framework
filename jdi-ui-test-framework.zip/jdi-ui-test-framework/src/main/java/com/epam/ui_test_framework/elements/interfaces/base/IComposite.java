package com.epam.ui_test_framework.elements.interfaces.base;

/**
 * Created by Roman_Iovlev on 7/10/2015.
 */
public interface IComposite {
}
