package com.epam.ui_test_framework.utils.common;

/**
 * Created by roman.i on 19.11.2014.
 */
public class StringUtils {
    public static String LineBreak = System.getProperty("line.separator");
}
