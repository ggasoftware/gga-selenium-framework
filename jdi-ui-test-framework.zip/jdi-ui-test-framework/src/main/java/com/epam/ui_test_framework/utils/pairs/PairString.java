package com.epam.ui_test_framework.utils.pairs;

/**
 * Created by 12345 on 30.09.2014.
 */

public class PairString extends Pair<String, String> {
    public PairString(String value1, String value2) { super(value1, value2); }
}
