package com.epam.ui_test_framework.logger.enums;

/**
 * Created by Roman_Iovlev on 6/9/2015.
 */
public enum BusinessInfoTypes {
    INIT,
    SUIT,
    TEST,
    STEP
}
