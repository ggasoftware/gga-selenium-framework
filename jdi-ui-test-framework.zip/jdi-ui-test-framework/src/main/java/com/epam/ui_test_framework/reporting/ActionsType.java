package com.epam.ui_test_framework.reporting;

/**
 * Created by Roman_Iovlev on 7/26/2015.
 */
public enum ActionsType {
    JDI_ACTION
}
