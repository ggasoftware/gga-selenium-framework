package com.epam.ui_test_framework.testRunner;

/**
 * Created by Roman_Iovlev on 6/9/2015.
 */
public class TestNGRunner implements ITestRunner {

}
