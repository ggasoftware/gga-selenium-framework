package com.epam.ui_test_framework.utils.linqInterfaces;

/**
 * Created by roman.i on 01.10.2014.
 */
public interface JAction {
    void invoke() throws Exception;
}
