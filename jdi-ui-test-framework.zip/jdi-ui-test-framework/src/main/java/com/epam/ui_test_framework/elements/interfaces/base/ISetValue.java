package com.epam.ui_test_framework.elements.interfaces.base;

/**
 * Created by Roman_Iovlev on 7/6/2015.
 */
public interface ISetValue extends IHaveValue {
    /** Set value to element */
    void setValue(String value);
}
