package com.epam.ui_test_framework.settings;

/**
 * Created by Roman_Iovlev on 7/27/2015.
 */
public class FrameworkData {
    public static String frameworkName = "Jedi Viqa";
    public static String applicationVersion = "2.0.0";

    // TODO need to remove
    public static String testName;
}
