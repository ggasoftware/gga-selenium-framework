package com.epam.ui_test_framework.elements.interfaces.complex;

import com.epam.ui_test_framework.elements.interfaces.base.IMultiSelector;

/**
 * Created by Roman_Iovlev on 6/10/2015.
 */
public interface ICheckList<TEnum extends Enum> extends IMultiSelector<TEnum> {

}
