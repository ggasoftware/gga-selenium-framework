package com.epam.ui_test_framework.elements.apiInteract;

/**
 * Created by 12345 on 30.09.2014.
 */
public enum ContextType { Locator, Frame }

