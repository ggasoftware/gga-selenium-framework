package com.epam.ui_test_framework.elements.page_objects.annotations.functions;

/**
 * Created by Roman_Iovlev on 7/21/2015.
 */
public enum Functions {
    NONE,
    OK_BUTTON,
    CLOSE_BUTTON,
    CANCEL_BUTTON
}
