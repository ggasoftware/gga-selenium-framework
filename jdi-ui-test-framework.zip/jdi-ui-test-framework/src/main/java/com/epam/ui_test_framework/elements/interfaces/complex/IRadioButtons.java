package com.epam.ui_test_framework.elements.interfaces.complex;

import com.epam.ui_test_framework.elements.interfaces.base.ISelector;

/**
 * Created by Roman_Iovlev on 6/10/2015.
 */
public interface IRadioButtons<TEnum extends Enum> extends ISelector<TEnum> {
}
