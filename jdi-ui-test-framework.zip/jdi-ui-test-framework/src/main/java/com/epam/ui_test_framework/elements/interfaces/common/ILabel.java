package com.epam.ui_test_framework.elements.interfaces.common;

import com.epam.ui_test_framework.elements.interfaces.base.IClickable;

/**
 * Created by Roman_Iovlev on 6/10/2015.
 */
public interface ILabel extends IClickable, IText {
}
