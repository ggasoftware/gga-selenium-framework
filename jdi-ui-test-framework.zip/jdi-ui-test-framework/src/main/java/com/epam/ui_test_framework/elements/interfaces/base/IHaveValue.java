package com.epam.ui_test_framework.elements.interfaces.base;

/**
 * Created by Roman_Iovlev on 6/10/2015.
 */
public interface IHaveValue {
    /** Get value of element */
    String getValue();
}
